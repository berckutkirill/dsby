<?php
/**
 * Created by PhpStorm
 * User: Sergey Pokoev
 * www.pokoev.ru
 * @ Академия 1С-Битрикс - 2015
 * @ academy.1c-bitrix.ru
 */
$arModuleVersion = array(
	"VERSION" => "1.0.0",
	"VERSION_DATE" => "2016-04-13 14:15:00"
);
