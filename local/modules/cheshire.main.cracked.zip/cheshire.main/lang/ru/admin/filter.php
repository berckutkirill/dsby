<?php
$MESS["CHESHIRE_MAIN_TITLE"] = "Rafail";
$MESS["CHESHIRE_MAIN_FILTER_URL"] = "Url";
$MESS["CHESHIRE_MAIN_FILTER_H1"] = "H1";
$MESS["CHESHIRE_MAIN_FILTER_SEO_TITLE"] = "Titile";
$MESS["CHESHIRE_MAIN_FILTER_SEO_KEYWORDS"] = "Keywords";
$MESS["CHESHIRE_MAIN_FILTER_SEO_DESCRIPTION"] = "Description";
$MESS["DELETE_ERROR"] = "Ошибка удаления.";
$MESS["CHESHIRE_MAIN_FILTER_SUBMIT"] = "Submit";
$MESS["CHESHIRE_MAIN_ROW_ADDED"] = "Запись успешно добавлена";
$MESS["CHESHIRE_MAIN_PAGES"] = "Страница";
$MESS["CHESHIRE_MAIN_EDIT"] = "Edit";
$MESS["CHESHIRE_MAIN_ADD"] = "Add";
$MESS["CONFIRM_DEL_MESSAGE"] = "Вы действительно хотите удалить данную запись?";

