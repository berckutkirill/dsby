<?php

$MESS["CHESHIRE_MAIN_MODULE_NAME"] = "ЧПУ Фильтр";
$MESS["CHESHIRE_MAIN_MODULE_DESC"] = "Удаление этого модуля сложит сайт";
$MESS["CHESHIRE_MAIN_PARTNER_NAME"] = "Раф";
$MESS["CHESHIRE_MAIN_PARTNER_URI"] = "http://vk.com/id18932782";
?>